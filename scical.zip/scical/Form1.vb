﻿Public Class Form1
	Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

	End Sub

	Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

	End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub Button42_Click(sender As Object, e As EventArgs) Handles Button42.Click

    End Sub
End Class
