﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Green
        Me.Panel1.Location = New System.Drawing.Point(9, 8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(300, 96)
        Me.Panel1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button1.Location = New System.Drawing.Point(139, 110)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(38, 28)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "↑"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button2.Location = New System.Drawing.Point(140, 167)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(38, 26)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "↓"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button3.Location = New System.Drawing.Point(103, 138)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(38, 28)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "←"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button4.Location = New System.Drawing.Point(177, 138)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(38, 28)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "→"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.25!)
        Me.Button5.ForeColor = System.Drawing.Color.Black
        Me.Button5.Location = New System.Drawing.Point(9, 110)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(45, 28)
        Me.Button5.TabIndex = 5
        Me.Button5.Text = "SHIFT"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!)
        Me.Button6.Location = New System.Drawing.Point(60, 110)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 28)
        Me.Button6.TabIndex = 6
        Me.Button6.Text = "ALPHA"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button7.Location = New System.Drawing.Point(264, 110)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(45, 28)
        Me.Button7.TabIndex = 8
        Me.Button7.Text = "ON"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.25!)
        Me.Button8.Location = New System.Drawing.Point(213, 110)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(45, 28)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "MODE"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button9.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button9.Location = New System.Drawing.Point(60, 167)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(45, 26)
        Me.Button9.TabIndex = 10
        Me.Button9.Text = "∫▄"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button10.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button10.Location = New System.Drawing.Point(9, 167)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(45, 26)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "CALC"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.25!)
        Me.Button11.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button11.Location = New System.Drawing.Point(264, 167)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(45, 26)
        Me.Button11.TabIndex = 12
        Me.Button11.Text = "log□▐"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button12.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button12.Location = New System.Drawing.Point(213, 167)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(45, 26)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "xˉ¹"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button13.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button13.Location = New System.Drawing.Point(60, 204)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(45, 28)
        Me.Button13.TabIndex = 14
        Me.Button13.Text = "√■"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button14.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button14.Location = New System.Drawing.Point(9, 204)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(45, 28)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "▀/▄"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button15.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button15.Location = New System.Drawing.Point(162, 204)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(45, 28)
        Me.Button15.TabIndex = 16
        Me.Button15.Text = "x"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button16.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button16.Location = New System.Drawing.Point(111, 204)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(45, 28)
        Me.Button16.TabIndex = 15
        Me.Button16.Text = "x²"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button17.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button17.Location = New System.Drawing.Point(264, 204)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(45, 28)
        Me.Button17.TabIndex = 18
        Me.Button17.Text = "ln"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button18.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button18.Location = New System.Drawing.Point(213, 204)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(45, 28)
        Me.Button18.TabIndex = 17
        Me.Button18.Text = "log"
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button19.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button19.Location = New System.Drawing.Point(264, 245)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(45, 28)
        Me.Button19.TabIndex = 24
        Me.Button19.Text = "tan"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button20.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button20.Location = New System.Drawing.Point(213, 245)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(45, 28)
        Me.Button20.TabIndex = 23
        Me.Button20.Text = "cos"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button21.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button21.Location = New System.Drawing.Point(162, 245)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(45, 28)
        Me.Button21.TabIndex = 22
        Me.Button21.Text = "sin"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button22.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button22.Location = New System.Drawing.Point(111, 245)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(45, 28)
        Me.Button22.TabIndex = 21
        Me.Button22.Text = "hyp"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button23
        '
        Me.Button23.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button23.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button23.Location = New System.Drawing.Point(60, 245)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(45, 28)
        Me.Button23.TabIndex = 20
        Me.Button23.Text = ".,,,"
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button24.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button24.Location = New System.Drawing.Point(9, 245)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(45, 28)
        Me.Button24.TabIndex = 19
        Me.Button24.Text = "( - )"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button25.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button25.Location = New System.Drawing.Point(264, 284)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(45, 28)
        Me.Button25.TabIndex = 30
        Me.Button25.Text = "M+"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button26.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button26.Location = New System.Drawing.Point(213, 284)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(45, 28)
        Me.Button26.TabIndex = 29
        Me.Button26.Text = "S⇔D"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button27.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button27.Location = New System.Drawing.Point(162, 284)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(45, 28)
        Me.Button27.TabIndex = 28
        Me.Button27.Text = "}"
        Me.Button27.UseVisualStyleBackColor = False
        '
        'Button28
        '
        Me.Button28.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button28.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button28.Location = New System.Drawing.Point(111, 284)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(45, 28)
        Me.Button28.TabIndex = 27
        Me.Button28.Text = "("
        Me.Button28.UseVisualStyleBackColor = False
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button29.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button29.Location = New System.Drawing.Point(60, 284)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(45, 28)
        Me.Button29.TabIndex = 26
        Me.Button29.Text = "ENG"
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button30.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button30.Location = New System.Drawing.Point(9, 284)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(45, 28)
        Me.Button30.TabIndex = 25
        Me.Button30.Text = "RCL"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button31.Location = New System.Drawing.Point(256, 332)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(53, 33)
        Me.Button31.TabIndex = 35
        Me.Button31.Text = "AC"
        Me.Button31.UseVisualStyleBackColor = False
        '
        'Button32
        '
        Me.Button32.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button32.Location = New System.Drawing.Point(197, 332)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(53, 33)
        Me.Button32.TabIndex = 34
        Me.Button32.Text = "DEL"
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button33
        '
        Me.Button33.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button33.Location = New System.Drawing.Point(127, 332)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(53, 33)
        Me.Button33.TabIndex = 33
        Me.Button33.Text = "9"
        Me.Button33.UseVisualStyleBackColor = False
        '
        'Button34
        '
        Me.Button34.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button34.Location = New System.Drawing.Point(68, 332)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(53, 33)
        Me.Button34.TabIndex = 32
        Me.Button34.Text = "8"
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button35.Location = New System.Drawing.Point(9, 332)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(53, 33)
        Me.Button35.TabIndex = 31
        Me.Button35.Text = "7"
        Me.Button35.UseVisualStyleBackColor = False
        '
        'Button36
        '
        Me.Button36.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button36.Location = New System.Drawing.Point(127, 377)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(53, 33)
        Me.Button36.TabIndex = 38
        Me.Button36.Text = "6"
        Me.Button36.UseVisualStyleBackColor = False
        '
        'Button37
        '
        Me.Button37.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button37.Location = New System.Drawing.Point(68, 377)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(53, 33)
        Me.Button37.TabIndex = 37
        Me.Button37.Text = "5"
        Me.Button37.UseVisualStyleBackColor = False
        '
        'Button38
        '
        Me.Button38.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button38.Location = New System.Drawing.Point(9, 377)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(53, 33)
        Me.Button38.TabIndex = 36
        Me.Button38.Text = "4"
        Me.Button38.UseVisualStyleBackColor = False
        '
        'Button39
        '
        Me.Button39.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button39.Location = New System.Drawing.Point(127, 424)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(53, 31)
        Me.Button39.TabIndex = 41
        Me.Button39.Text = "3"
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button40.Location = New System.Drawing.Point(68, 424)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(53, 31)
        Me.Button40.TabIndex = 40
        Me.Button40.Text = "2"
        Me.Button40.UseVisualStyleBackColor = False
        '
        'Button41
        '
        Me.Button41.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button41.Location = New System.Drawing.Point(9, 424)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(53, 31)
        Me.Button41.TabIndex = 39
        Me.Button41.Text = "1"
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button42.Location = New System.Drawing.Point(127, 469)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(53, 31)
        Me.Button42.TabIndex = 44
        Me.Button42.Text = "x10˟"
        Me.Button42.UseVisualStyleBackColor = False
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button43.Location = New System.Drawing.Point(68, 469)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(53, 31)
        Me.Button43.TabIndex = 43
        Me.Button43.Text = "."
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button44.Location = New System.Drawing.Point(9, 469)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(53, 31)
        Me.Button44.TabIndex = 42
        Me.Button44.Text = "0"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'Button45
        '
        Me.Button45.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button45.Location = New System.Drawing.Point(257, 377)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(53, 33)
        Me.Button45.TabIndex = 46
        Me.Button45.Text = "÷"
        Me.Button45.UseVisualStyleBackColor = False
        '
        'Button46
        '
        Me.Button46.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button46.Location = New System.Drawing.Point(198, 377)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(53, 33)
        Me.Button46.TabIndex = 45
        Me.Button46.Text = "x"
        Me.Button46.UseVisualStyleBackColor = False
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button47.Location = New System.Drawing.Point(257, 468)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(53, 33)
        Me.Button47.TabIndex = 50
        Me.Button47.Text = "="
        Me.Button47.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button48.Location = New System.Drawing.Point(198, 468)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(53, 33)
        Me.Button48.TabIndex = 49
        Me.Button48.Text = "Ans"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button49.Location = New System.Drawing.Point(256, 423)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(53, 33)
        Me.Button49.TabIndex = 48
        Me.Button49.Text = "-"
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button50.Location = New System.Drawing.Point(197, 423)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(53, 33)
        Me.Button50.TabIndex = 47
        Me.Button50.Text = "+"
        Me.Button50.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(318, 525)
        Me.Controls.Add(Me.Button47)
        Me.Controls.Add(Me.Button48)
        Me.Controls.Add(Me.Button49)
        Me.Controls.Add(Me.Button50)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.Button46)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
	Friend WithEvents Button1 As Button
	Friend WithEvents Button2 As Button
	Friend WithEvents Button3 As Button
	Friend WithEvents Button4 As Button
	Friend WithEvents Button5 As Button
	Friend WithEvents Button6 As Button
	Friend WithEvents Button7 As Button
	Friend WithEvents Button8 As Button
	Friend WithEvents Button9 As Button
	Friend WithEvents Button10 As Button
	Friend WithEvents Button11 As Button
	Friend WithEvents Button12 As Button
	Friend WithEvents Button13 As Button
	Friend WithEvents Button14 As Button
	Friend WithEvents Button15 As Button
	Friend WithEvents Button16 As Button
	Friend WithEvents Button17 As Button
	Friend WithEvents Button18 As Button
	Friend WithEvents Button19 As Button
	Friend WithEvents Button20 As Button
	Friend WithEvents Button21 As Button
	Friend WithEvents Button22 As Button
	Friend WithEvents Button23 As Button
	Friend WithEvents Button24 As Button
	Friend WithEvents Button25 As Button
	Friend WithEvents Button26 As Button
	Friend WithEvents Button27 As Button
	Friend WithEvents Button28 As Button
	Friend WithEvents Button29 As Button
	Friend WithEvents Button30 As Button
	Friend WithEvents Button31 As Button
	Friend WithEvents Button32 As Button
	Friend WithEvents Button33 As Button
	Friend WithEvents Button34 As Button
	Friend WithEvents Button35 As Button
	Friend WithEvents Button36 As Button
	Friend WithEvents Button37 As Button
	Friend WithEvents Button38 As Button
	Friend WithEvents Button39 As Button
	Friend WithEvents Button40 As Button
	Friend WithEvents Button41 As Button
	Friend WithEvents Button42 As Button
	Friend WithEvents Button43 As Button
	Friend WithEvents Button44 As Button
	Friend WithEvents Button45 As Button
	Friend WithEvents Button46 As Button
	Friend WithEvents Button47 As Button
	Friend WithEvents Button48 As Button
	Friend WithEvents Button49 As Button
	Friend WithEvents Button50 As Button
End Class
